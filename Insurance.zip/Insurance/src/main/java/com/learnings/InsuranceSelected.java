package com.learnings;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

public class InsuranceSelected extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//String insurance = request.getParameter("insurances");
		
		String zipcode = request.getParameter("zipcode");
		String state = request.getParameter("state");
		String country = request.getParameter("country");
		String samePage = request.getParameter("samePage");
		                                                      //url read
		
		
		PrintWriter out = response.getWriter();//printwriter obj
		
		
		try{ 
            
            if(null != samePage && samePage.equals("yes")) {
            	response.setContentType("application/json;charset=utf-8");  
            	String jdbcUrl="jdbc:mysql://localhost:3306/emp";
    	        String username="root";
    	        String password="Kentang@123";
    	        Connection connection=null;
    	        connection= DriverManager.getConnection(jdbcUrl,username,password);
    	        Statement stmt1=connection.createStatement();  
    	        ResultSet rs1=stmt1.executeQuery("select * from zip where zip="+ zipcode);
    	        while(rs1.next()) {
    	        	 JSONObject member =  new JSONObject();

    	    	        member.put("zipcode", rs1.getInt(1));
    	    	        member.put("state", rs1.getString(3));
    	    	        member.put("city", rs1.getString(2));
    	    	        out.print(member.toString());
    	        	
    	        }
            	connection.close();  
            }else {
            	response.setContentType("text/html");  
            	String jdbcUrl="jdbc:mysql://localhost:3306/emp";
    	        String username="root";
    	        String password="Kentang@123";
    	        Connection connection=null;
    	        connection= DriverManager.getConnection(jdbcUrl,username,password);
            	Statement stmt=connection.createStatement(); 
            	ResultSet rs=stmt.executeQuery("select * from zip where zip="+ zipcode);
            	  
            while(rs.next()) { 
            	
            //out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
            
            out.println("<h1>Customer Information</h1>");
    		out.println("<p>Personal information to provide you with an accurate quote.</p>\r\n"
    				+ "    <hr>");
    		out.println("<br><br>\r\n"
    				+ "  <label for=\"fname\">First Name : </label>\r\n"
    				+ "  <input type=\"text\" placeholder=\"Enter Name\" id=\"fname\" required>\r\n"
    				+ "    <br><br>\r\n"
    				+ "  <label for=\"lname\">Last Name :</label>\r\n"
    				+ "  <input type=\"text\" placeholder=\"Enter Name\" id=\"lname\" required>\r\n"
    				+ "   <br><br>\r\n"
    				+ "  <label for=\"address\">Address : </label>\r\n"
    				+ "  <input type=\"text\" placeholder=\"Enter Address\" id=\"address\" required>\r\n"
    				+ "   <br><br>\r\n"
    				+ "  <label for=\"zipcode\">Zip Code : </label>\r\n"
    				+ "  <input type=\"text\" id=\"zipcode\" name=\"zipcode\" value=\""+ rs.getInt(1) + "\"maxlength=\"5\">\r\n"
    				+ "   <br><br>\r\n"
    				+ "   <label for=\"state\">State : </label>\r\n"
    				+ "  <input type=\"text\" id=\"state\" name=\"state\" value=\""+ rs.getString(3) +  "\" required>\r\n"
    				+ "   <br><br>\r\n"
    				+ "   <label for=\"city\">City :</label>\r\n"
    				+ "  <input type=\"text\" id=\"city\" name=\"city\" value=\""+ rs.getString(2) +  "\" required>\r\n"
    				+ "   <br><br>\r\n"
    				+ "    <label for=\"country\">Country :</label>\r\n"
    				+ "  <input type=\"text\" id=\"country\" name=\"country\"  required>\r\n"
    				+ "   <br><br>\r\n"
    				+ "  <label>\r\n"
    				+ "    Date of Birth: <input type = \"date\"> \r\n"
    				+ "  </label>\r\n"
    				+ "  <br></br>");
    		out.println(" <p>-- <b>Select 'YES' if ANY of the following apply to you:</b>.</p>\r\n"
    				+ "  <ul>\r\n"
    				+ " <li>I need to insure more than one driver</li>\r\n"
    				+ " <li for=\"vechile\">I need to insure more than one vechile </li>\r\n"
    				+ " <li>I am married</li> <br></br>\r\n"
    				+ "     <input type=\"radio\" name=\"yes_no\" checked>Yes</input>\r\n"
    				+ "     <input type=\"radio\" name=\"yes_no\">No</input>\r\n"
    				+ " </ul><br></br>\r\n"
    				+ "<input type=\"submit\" value=\"Continue\">");
    		
    		out.println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js\"></script>");
    		out.println("<script type=\"text/javascript\" src="+ "/Insurance/demoscript.js"+"></script>");
            }
            rs.close();
            connection.close();
            }
            
            
		  
		}catch (SQLException e2) {System.out.println(e2);}  
        
		out.close(); 
		}
		

}
	
