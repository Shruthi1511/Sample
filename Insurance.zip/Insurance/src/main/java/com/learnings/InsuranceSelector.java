package com.learnings;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InsuranceSelector extends HttpServlet {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String insurance = request.getParameter("insurances");
		String zipcode = request.getParameter("zipcode");
		
		response.sendRedirect("http://localhost:4506/Insurance/servlet/insuranceSelected"+ "?insurances=" +insurance + "&zipcode=" + zipcode);
		
	}

}
