$(document).ready(function () {
  $("#zipcode").change(function (event) {
	
    var formData = {
      zipcode: $("#zipcode").val(),
      samePage : "yes"
    };

    $.ajax({

            url : "http://localhost:4506/Insurance/servlet/insuranceSelected",
            data: formData,
            dataType : 'json',
            error : function() {

                alert("Error Occured");
            },
            success : function(data) {
               // var obj=$.parseJSON(data);
           $('#state').val(data.state);
           $('#city').val(data.city);
           

            }
        });

    event.preventDefault();
  });
});